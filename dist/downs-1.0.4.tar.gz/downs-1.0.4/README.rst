downs - Multithreaded Download Tools
====================================

.. image:: https://img.shields.io/pypi/v/downs.svg
   :target: https://pypi.org/project/downs/

Multithreaded download tools for Python. 

You can use pip to install packages from the `Python Package Index`_ and other indexes.

* `GitHub page`_
* `Issue tracking`_

.. _Python Package Index: https://pypi.org
.. _GitHub page: https://github.com/userelaina/downs
.. _Issue tracking: https://github.com/userelaina/downs/issues
